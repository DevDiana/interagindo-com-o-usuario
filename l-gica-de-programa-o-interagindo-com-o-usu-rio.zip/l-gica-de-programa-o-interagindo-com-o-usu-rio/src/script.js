

    function pulaLinha() {

        document.write("<br>");
        document.write("<br>");
}

    function mostra(frase) {

        document.write(frase);
        pulaLinha();
}

    function calculaImc(altura, peso) {

        return peso / (altura * altura);
}
var nome = prompt('Digite seu nome')
var alturaInformada = prompt(nome + ' Informe sua altura');
var pesoInformado = prompt(nome +  ' Informe seu peso');

var imc = calculaImc( nome + "o seu imc é: " alturaInformada, pesoInformado);

document.write("O IMC calculado é: " + imc);

