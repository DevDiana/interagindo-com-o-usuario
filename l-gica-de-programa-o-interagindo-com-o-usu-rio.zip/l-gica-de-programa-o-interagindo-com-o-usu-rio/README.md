# Lógica de programação-Interagindo com o usuário

A Pen created on CodePen.io. Original URL: [https://codepen.io/devdiana/pen/vYRENgw](https://codepen.io/devdiana/pen/vYRENgw).

